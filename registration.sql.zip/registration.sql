-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 08, 2022 at 07:59 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `number` varchar(13) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `email`, `password`, `address`, `number`) VALUES
(1, 'Sadhana kumari', 'sadhanakumari635', '2345678', 'Vill+Post - Newada  Dist-Ghazipur', '9876754321'),
(2, 'Sadhana kumari', 'sadhanakumari635', '12344567', 'Vill+Post - Newada  Dist-Ghazipur', '96892059262'),
(3, 'Sadhana kumari', 'sadhanakumari635', '12344567', 'Vill+Post - Newada  Dist-Ghazipur', '96892059262'),
(4, 'Sadhana kumari', 'sadhanakumari635', '2345678', 'Vill+Post - Newada  Dist-Ghazipur', '9876754321'),
(5, 'Anjali', 'anj@gmail.com', '99999', 'Dhana shiv mandir\r\nShiv mandir', '8783463455'),
(6, 'anuu', 'anu123@gmail.com', '99999', 'Varanasi', '8985476711'),
(7, 'Deepu', 'deep@gmail.com', '131313', 'Gurugram', '8570857074'),
(8, 'Pinki', 'piku2@gail.com', 'piku', 'Vill+Post - Newada  Dist-Ghazipur', '9856213458'),
(9, 'durgesh yadav', 'durgeshkumar@iwc', 'demo1234', 'agra', '9956231254232'),
(10, 'durgesh yadav', 'durgeshkumar@iwcnetwork.com', 'demo1234', 'Agra', '68908067655'),
(11, 'Ishika Gupta', 'ishu06@gmail.com', '12345678', 'Dhana shiv mandir Shiv mandir', '98765456789'),
(12, 'Ishika Gupta', 'ishu06@gmail.com', '12345678', 'Dhana shiv mandir Shiv mandir', '98765456789'),
(13, 'Annn', 'ann@gmail.com', '123456', 'Vill+Post - Newada  Dist-Ghazipur', '9876754321'),
(14, 'Annn', 'ann@gmail.com', '123456', 'Vill+Post - Newada  Dist-Ghazipur', '9876754321'),
(15, 'Sadhana kumari', 'sadhanakumari63558@gmail.com', 'jhghrttfdd', 'Vill+Post - Newada  Dist-Ghazipur', '78765432234'),
(16, 'Babita', 'babita@2002gmail.com', '234567', 'gurugram', '9879874984'),
(17, 'Babita', 'babita@2002gmail.com', '234567', 'gurugram', '9879874984'),
(18, 'Babita', 'babita@2002gmail.com', '234567', 'gurugram', '9879874984'),
(19, 'Ishika ', 'ishu@gmail.com', 'ishu', 'haryana', '8738859032'),
(20, 'Ishika ', 'ishu@gmail.com', 'ishu', 'haryana', '8738859032'),
(21, 'Sadhana kumari', 'sadhanakumari63558@gmail.com', '000000', 'Vill+Post - Newada  Dist-Ghazipur', '98765432345'),
(22, 'dipu', 'dip@gmail.com', 'dip', 'dhumaspur badshahpur haryana', '8570857074'),
(23, 'Jatin', 'jchandravansi23@gmail.com', 'jatin', 'IIT roorkee uttarakhand', '8975321237'),
(24, 'Sadhana kumari', 'sadhanakumari63558@gmail.com', '1234', 'Vill+Post - Newada  Dist-Ghazipur', '987654'),
(25, 'anita ', 'ann@gmail.com', 'annni', 'Goa', '9876543232'),
(26, 'Akhil', 'ak12@gmail.com', 'akhilesh', 'Pune maharastra', '98765445678');
